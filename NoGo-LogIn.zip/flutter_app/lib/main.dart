// need to add API key

import 'package:flutter/material.dart';
//import 'package:google_maps_flutter/google_maps_flutter.dart';


void main() => runApp(new MyApp());

class MyApp extends StatelessWidget(
  @override
Widget build(BuildContext context) {
    return new MaterialApp(
      home: new LoginPage(),
      theme: new ThemeData(
        primarySwatch: Colors.blueGrey
      ) // ThemeData
    ); // Material App
  }
)

class LoginPage extends StatefulWidget{
  @override
  State createState() => new LoginPageState();
}

class LoginPageState extends State<LoginPage>{
  AnimationController _iconAnimationController; 
  Animation<double> _iconAnimation; 
  
  @override
  void initState(){
    super.initState(); 
    _iconAnimationController = new AnimationController(
      vsync: this, duration: new Duration(milliseconds: 500)); //AnimationController
    _iconAnimation = new CurvedAnimation(
      parent: _iconAnimationController, curve: Curves.easeOut);
    _iconAnimation.addListener(() => this.setState(() {}));
  _iconAnimationController.forward();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.blueGrey,
      body: new Stack(
        fit: StackFit.expand,
        children: <Widget>[
          new Image(
         // image: new NAME
          // look for image/icon for login, add to asset as well
          //fit: BoxFit.cover,
         // color: Color.Grey12,
          ), // image
          new Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              new FlutterLogo(
                size: _iconAnimation.value * 100,
              ), // Flutter logo
              new Form(
                child: new Column(
                  children: <Widget>[
                    new TextFormField(
                      decoration: new InputDecoration(
                        hintText: "Enter Name",
                    ), // input decoration
                       keyboardType: TextInputType.text,
              ), //TextFormField
      new TextFormField(
        decoration: new InputDecoration(
          hintText: "Enter Password",
        ), // InputDecoration
        keyboardType: TextInputType.text,
        obscureText: true,
      ), //Text form field
    ],//<Widget>[]
    ), //Column
    ),  //Form
        ],  // <Widget> []
      ), // Stack
      // add additional features, change color, etc.
    ); // Scaffold
  }
}


/* below is basis for initial page once logging in, still working on it
void main() => runApp(
      MaterialApp(
        home: Scaffold(
          // creating home area where user can determine which features
          //they should interact with
          // this assumes that they have already logged into the Application
          backgroundColor: Colors.blueGrey,
          body: Center(
            child: Text('display application features here:'),
          ),
          appBar: AppBar(
            title: Text('NoGo home'),
            backgroundColor: Colors.blueGrey[900],
          ), //AppBar, can change many things within this class
        ), //Scaffold
        debugShowCheckedModeBanner: false,
      ), //MaterialApp
    );

 */
